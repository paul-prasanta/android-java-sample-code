package com.pras.feed;

import android.net.Uri;

public class Content {

	String title;
	String description;
	String moreText;
	String img;
	
	public Content(String title, String description, String moreText, String img){
		this.title = title;
		this.description = description;
		this.moreText = moreText;
		this.img = img;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}

	public String getMoreText() {
		return moreText;
	}

	public void setMoreText(String moreText) {
		this.moreText = moreText;
	}
	
}
