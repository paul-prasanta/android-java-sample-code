package com.pras.feed;

import java.util.ArrayList;

import android.net.Uri;

public class DataPull {

	public static ArrayList<Content> contents = new ArrayList<Content>();
	static {
		contents.add(new Content("Its Me", 
								 "What about sing a song...",
								 "Lets play Kolaveri Di. Lets add few more and rock n roll....",
								"images/tajmahal.jpg"
								 ));
		
		contents.add(new Content("Place", 
				 "Its the time...", 
				 "Here we are, at the northan part of the country, 2 gigantic tower....",
				 "images/place.jpg"
				 ));

		contents.add(new Content("Lets Meet", 
				 "there no limit. Endless life...", 
				 "What abt going out and get some Thai food. We'll have both green and red curry and white wine...",
				 "images/meet.jpg"
				 ));

		contents.add(new Content("Travel arround the world", 
				 "Where else it can be, starts at Nappa Velly, ends at Seoul...", 
				 "It starts at San Jose, then next day at Maryland, then to Sandiego, then to Seattle, then to Dallas, then to Dubai, then to Bharain, " +
				 "then to London, then to Amsterdam, then to Bhutan, then to South Korea and then to Thailand",
				 "images/travel.jpg"
				 ));
	}
}
