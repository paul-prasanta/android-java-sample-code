package com.pras;

import com.pras.feed.Content;
import com.pras.frags.DetailFrag;
import com.pras.frags.FragmentInterface;
import com.pras.frags.MyPlayerFrag;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;

public class AndroidICSFirstActivity extends Activity implements FragmentInterface {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // Set the Fragment width- 50% for each Fragment
        int screenWidth = getWindowManager().getDefaultDisplay().getWidth();
        int leftFragWidth = (int)(screenWidth * 0.50);
        int rightFragWidth = (int)(screenWidth * 0.50);
        
        LinearLayout.LayoutParams leftParm = new LinearLayout.LayoutParams(leftFragWidth, LinearLayout.LayoutParams.MATCH_PARENT);
        LinearLayout.LayoutParams rightParm = new LinearLayout.LayoutParams(rightFragWidth, LinearLayout.LayoutParams.MATCH_PARENT);
        
        findViewById(R.id.list_frag_layout).setLayoutParams(leftParm);
        findViewById(R.id.player_frag_layout).setLayoutParams(rightParm);
    }

	@Override
	public void showImage(Content content) {
		
		// Update Player Fragment - MyPlayerFrag
		MyPlayerFrag playerFrag = (MyPlayerFrag) getFragmentManager().findFragmentById(R.id.player_frag);
		playerFrag.updateImage(content);
		
		// Change List fragment with Detail Fragment
		FragmentManager fm = getFragmentManager();
		FragmentTransaction transaction = fm.beginTransaction();
		
		// Hide previous fragment
		transaction.hide(fm.findFragmentById(R.id.list_frag));
		
		// Add this new Fragment into the layout
		DetailFrag detailFrag = new DetailFrag();
		transaction.add(R.id.list_frag_layout, detailFrag);
		
		
		// Add to this transaction into BackStack
		transaction.addToBackStack(null);
		
		// Commit this transaction
		transaction.commit();
	}
}