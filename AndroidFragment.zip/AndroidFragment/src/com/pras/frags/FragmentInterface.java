package com.pras.frags;

import com.pras.feed.Content;

public interface FragmentInterface {

	public void showImage(Content content);
}
