package com.pras.frags;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pras.R;
import com.pras.feed.Content;
import com.pras.feed.DataPull;

public class MyListAdapter extends BaseAdapter  {

	Context context;
	public MyListAdapter(Context context) {
		this.context = context;
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return DataPull.contents.size();
	}

	@Override
	public Object getItem(int index) {
		// TODO Auto-generated method stub
		return DataPull.contents.get(index);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		Content c = DataPull.contents.get(position);
		
		// Inflate the List Item view
		LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		LinearLayout layout = (LinearLayout)inflater.inflate(R.layout.list_item_main, parent, false);
		
		((TextView)layout.findViewById(R.id.text_title)).setText(c.getTitle());
		((TextView)layout.findViewById(R.id.text_desc)).setText(c.getDescription());
		
		layout.invalidate();
		
		return layout;
	}
	
}
