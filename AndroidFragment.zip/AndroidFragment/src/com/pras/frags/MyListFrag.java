package com.pras.frags;

import com.pras.R;
import com.pras.feed.Content;
import com.pras.feed.DataPull;

import android.app.Activity;
import android.app.ListFragment;
import android.content.Context;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MyListFrag extends ListFragment {


	Context context;
	FragmentInterface listener;
	
	@Override
	public void onAttach(Activity activity) {
		// TODO Auto-generated method stub
		super.onAttach(activity);
		this.context = activity.getApplicationContext();
		this.listener = (FragmentInterface) activity;
		
		setListAdapter(new MyListAdapter(activity.getApplicationContext()));
	}

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		// TODO Auto-generated method stub
		super.onListItemClick(l, v, position, id);
		
		Content c = DataPull.contents.get(position);
		Toast.makeText(context, c.getTitle(), Toast.LENGTH_SHORT).show();
		
		// Show more Text
		TextView moreText = (TextView) v.findViewById(R.id.text_more);
		if(moreText.getVisibility() == View.GONE){
			moreText.setText(c.getMoreText());
			moreText.setVisibility(View.VISIBLE);
		}
		else
			moreText.setVisibility(View.GONE);
		// handover call to Activity
		if(listener != null)
			listener.showImage(c);
	}

}
