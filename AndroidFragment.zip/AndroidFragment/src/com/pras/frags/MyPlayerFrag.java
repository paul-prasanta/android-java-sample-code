package com.pras.frags;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pras.R;
import com.pras.feed.Content;

public class MyPlayerFrag extends Fragment {
	
	Context context;
	ImageView playerImg;
	TextView caption;
	
	
	@Override
	public void onAttach(Activity activity) {
		this.context = activity.getApplicationContext();
		// TODO Auto-generated method stub
		super.onAttach(activity);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		LinearLayout player_layout = (LinearLayout) inflater.inflate(com.pras.R.layout.player, container, false);
//		VideoView video = (VideoView)player_layout.findViewById(R.id.video_view);
//		video.setVideoURI(Uri.parse("file:///android_asset/video/sample2.3gp"));
//		video.start();
		
		playerImg = (ImageView) player_layout.findViewById(R.id.image_view);
		caption = (TextView) player_layout.findViewById(R.id.caption);
		
		return player_layout;
	}
	
	public void updateImage(Content content){
		if(playerImg != null){
			try{
				Bitmap img = BitmapFactory.decodeStream(context.getAssets().open(content.getImg()));
				playerImg.setImageBitmap(img);
				playerImg.invalidate();
			}catch(Exception ex){
				ex.printStackTrace();
			}
		}
		if(caption != null)
			caption.setText(content.getTitle());
	}
}
