package pras.service;

import android.os.RemoteException;
import pras.service.aidl.PrasRemote;

public class MethodImpl extends PrasRemote.Stub {

	public String sayHello(String name) throws RemoteException {
		return "Hello "+ name;
	}

}
