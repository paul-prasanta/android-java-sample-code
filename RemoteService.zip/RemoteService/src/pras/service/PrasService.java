package pras.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class PrasService extends Service {

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		//return null;
		return new MethodImpl();
	}

}
