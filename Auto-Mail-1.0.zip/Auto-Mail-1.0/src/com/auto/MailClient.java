/*
 * Copyright (C) 2012 Prasanta Paul, http://prasanta-paul.blogspot.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.auto;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * Configurable Mail client to send bulk mails.
 *  
 * @author Prasanta Paul (http://prasanta-paul.blogspot.in/)
 */
public class MailClient {
	static final String TAG = "MailClient";
	
	private static boolean MAIL_DEBUG = false;
	private static String MAIL_FROM_NAME = "";
	private static String FROM = "";
	private static String PASSWORD = "";
	private static String MAIL_SERVER = "";
	private static String MAIL_PORT = "";
	private static String MAIL_PROTO = "";
	private static String EMAIL_SUB = "";
	private static String EMAIL_MSG = "";
	
	private static final String basePath = System.getProperty("user.dir"); 
	private static final String fs = File.separator;
	
	// Read Email configs
	static{
		Properties prop = new Properties();
		try 
		{
			System.out.println("basePath: "+ basePath);
			prop.load(new FileInputStream(basePath + fs + "mail" + fs + "mail-config.prop"));
			
			if(prop.getProperty("MAIL_DEBUG") != null && prop.getProperty("MAIL_DEBUG").toLowerCase().equals("yes"))
				MAIL_DEBUG = true;
			
			MAIL_FROM_NAME = prop.getProperty("MAIL_FROM_NAME");
			FROM = prop.getProperty("FROM");
			PASSWORD = prop.getProperty("PASSWORD");
			MAIL_SERVER = prop.getProperty("MAIL_SERVER");
			MAIL_PORT = prop.getProperty("MAIL_PORT");
			MAIL_PROTO = prop.getProperty("MAIL_PROTO");
			EMAIL_SUB = prop.getProperty("EMAIL_SUB");
			EMAIL_MSG = prop.getProperty("EMAIL_MSG");
		} 
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		finally{
			prop = null; // let it GC and all referenced Objects.
			
			System.out.println(MAIL_FROM_NAME);
			System.out.println(FROM);
			System.out.println(PASSWORD);
			System.out.println(MAIL_SERVER);
			System.out.println(MAIL_PORT);
			System.out.println(MAIL_PROTO);
			System.out.println(EMAIL_SUB);
			System.out.println(EMAIL_MSG);
		}
	}
	
	public static void v(String tag, String msg){
		System.out.println("["+ tag +"] "+ msg);
	}
	
	/**
	 * Send mails via your Mail Server. It takes few seconds to dispatch a mail.
	 * 
	 * @param from
	 * @param to
	 * @param subject
	 * @param msg
	 */
	public static void sendMail(String from, String to, String subject, String msg) throws Exception {

		// mail server conf.
		Properties mprop = new Properties();
		mprop.setProperty("mail.transport.protocol", MAIL_PROTO);
		mprop.setProperty("mail.host", MAIL_SERVER);
		
		mprop.put("mail.smtp.port", MAIL_PORT);
		mprop.put("mail.smtp.auth", "true");
		
		// Yahoo mail server complained with 553 exception: 553 Mail from 204.93.193.42 not allowed - [10]
		//mprop.put("mail.smtp.sendpartial", "true");
		
		// get mail session
		Session mailSession = Session.getDefaultInstance(mprop);
		
		mailSession.setDebug(MAIL_DEBUG);
		
		Transport mailTrans = mailSession.getTransport();
		
		// compose message
		MimeMessage message = new MimeMessage(mailSession);
		message.setFrom(new InternetAddress(from, MAIL_FROM_NAME));
		
		if(!to.contains(",")) // Only one Email
			message.setRecipients(Message.RecipientType.TO, to);
		else // Multiple email. user should not be able to see each other's email
			message.setRecipients(Message.RecipientType.BCC, to);
		
		message.setSubject(subject);
		message.setContent(msg, "text/html");

		// send/transport message
		mailTrans.connect(MAIL_SERVER, from, PASSWORD);
		
		v(TAG, "connected!!");
		mailTrans.sendMessage(message, message.getAllRecipients());
		mailTrans.close();
	}
	
	public static void readMailAddress(String file) throws Exception{
		// One line one email entry- name,abc@gmail.com
		BufferedReader fin = new BufferedReader(new FileReader(file));
		String line;
		String name = "";
		String email = "";
		String msg = "";
		
		while((line = fin.readLine()) != null)
		{
			v(TAG, "Sending mail to: "+ line);
			if(line == null || line.trim().equals("")){
				v(TAG, "Invalid entry. SKIP");
				continue;
			}
			name = line.substring(0, line.indexOf(",")).trim();
			email = line.substring(line.indexOf(",") + 1).trim();
			v(TAG, "Name: "+ name +" Email: "+ email);
			
			sendMail(FROM, email, EMAIL_SUB, "Hi "+ name +","+ EMAIL_MSG);
		}
		
		if(fin != null)
			fin.close();
		
		v(TAG, "DONE!!");
	}
	
	public static void main(String[] args){
		try{
			readMailAddress(basePath + fs + "mail" + fs + "mail.txt");
		}catch (Exception e) {
			v(TAG, "Error in sending mail: "+ e.toString());
			e.printStackTrace();
		}
	}
}
