/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\Workspace\\CallRemoteService\\src\\com\\sec\\android\\app\\sns\\ISnsRequester.aidl
 */
package com.sec.android.app.sns;
public interface ISnsRequester extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.sec.android.app.sns.ISnsRequester
{
private static final java.lang.String DESCRIPTOR = "com.sec.android.app.sns.ISnsRequester";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.sec.android.app.sns.ISnsRequester interface,
 * generating a proxy if needed.
 */
public static com.sec.android.app.sns.ISnsRequester asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = (android.os.IInterface)obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.sec.android.app.sns.ISnsRequester))) {
return ((com.sec.android.app.sns.ISnsRequester)iin);
}
return new com.sec.android.app.sns.ISnsRequester.Stub.Proxy(obj);
}
public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_authLogin:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
int _result = this.authLogin(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_authLogout:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
int _result = this.authLogout(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_authKeyResolve:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _result = this.authKeyResolve(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_authKeyDelete:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _result = this.authKeyDelete(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_activityForward:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
java.lang.String _arg1;
_arg1 = data.readString();
int _result = this.activityForward(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_activityRetrieve:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _result = this.activityRetrieve(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_commentPost:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
java.lang.String _arg4;
_arg4 = data.readString();
java.lang.String _arg5;
_arg5 = data.readString();
java.lang.String _arg6;
_arg6 = data.readString();
int _result = this.commentPost(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_commentRetrieve:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
java.lang.String _arg4;
_arg4 = data.readString();
java.lang.String _arg5;
_arg5 = data.readString();
boolean _arg6;
_arg6 = (0!=data.readInt());
int _result = this.commentRetrieve(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_commentRetrieveNext:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
java.lang.String _arg4;
_arg4 = data.readString();
java.lang.String _arg5;
_arg5 = data.readString();
int _result = this.commentRetrieveNext(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_friendListRetrieve:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
int _result = this.friendListRetrieve(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_messageFolderRetrieve:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _result = this.messageFolderRetrieve(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_messageGet:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
java.lang.String _arg4;
_arg4 = data.readString();
int _result = this.messageGet(_arg0, _arg1, _arg2, _arg3, _arg4);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_messagePost:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
java.lang.String[] _arg2;
_arg2 = data.createStringArray();
java.lang.String _arg3;
_arg3 = data.readString();
java.lang.String _arg4;
_arg4 = data.readString();
java.lang.String _arg5;
_arg5 = data.readString();
java.lang.String _arg6;
_arg6 = data.readString();
java.lang.String _arg7;
_arg7 = data.readString();
int _result = this.messagePost(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_messageThreadRetrieve:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
boolean _arg3;
_arg3 = (0!=data.readInt());
int _result = this.messageThreadRetrieve(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_messageThreadRetrieveNext:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
int _result = this.messageThreadRetrieveNext(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_notificationPost:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int[] _arg1;
_arg1 = data.createIntArray();
int _result = this.notificationPost(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_peopleProfileGet:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
int _result = this.peopleProfileGet(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_peopleProfileSet:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int[] _arg1;
_arg1 = data.createIntArray();
java.lang.String _arg2;
_arg2 = data.readString();
int _result = this.peopleProfileSet(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_photoAlbumGet:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
java.lang.String _arg2;
_arg2 = data.readString();
boolean _arg3;
_arg3 = (0!=data.readInt());
int _result = this.photoAlbumGet(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_photoAlbumGetNext:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
java.lang.String _arg2;
_arg2 = data.readString();
int _result = this.photoAlbumGetNext(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_photoAlbumRetrieve:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
boolean _arg4;
_arg4 = (0!=data.readInt());
int _result = this.photoAlbumRetrieve(_arg0, _arg1, _arg2, _arg3, _arg4);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_photoAlbumRetrieveNext:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
int _result = this.photoAlbumRetrieveNext(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_photoGet:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
int _result = this.photoGet(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_photoGetBody:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
java.lang.String _arg1;
_arg1 = data.readString();
int _result = this.photoGetBody(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_photoUpload:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
java.lang.String _arg4;
_arg4 = data.readString();
java.lang.String _arg5;
_arg5 = data.readString();
android.os.ParcelFileDescriptor _arg6;
if ((0!=data.readInt())) {
_arg6 = android.os.ParcelFileDescriptor.CREATOR.createFromParcel(data);
}
else {
_arg6 = null;
}
int _result = this.photoUpload(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_scheduleRetrieve:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _result = this.scheduleRetrieve(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_serviceProviderDeepLinkGet:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
java.lang.String _arg4;
_arg4 = data.readString();
java.lang.String _arg5;
_arg5 = data.readString();
java.lang.String _arg6;
_arg6 = data.readString();
java.lang.String _arg7;
_arg7 = data.readString();
int _result = this.serviceProviderDeepLinkGet(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_abortPhotoUpload:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
boolean _result = this.abortPhotoUpload(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_abortPhotoDownload:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
boolean _result = this.abortPhotoDownload(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_abortPhotoDownloadByRequestId:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
boolean _result = this.abortPhotoDownloadByRequestId(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_syncContactsNow:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
int _result = this.syncContactsNow(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_syncCalendarNow:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
int _result = this.syncCalendarNow(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_cancelSync:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
boolean _result = this.cancelSync(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_snsGatewayHostGet:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _result = this.snsGatewayHostGet(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_oAuthCredentialGet:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
int _result = this.oAuthCredentialGet(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.sec.android.app.sns.ISnsRequester
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
public int authLogin(int appID, int snsSp, java.lang.String id, java.lang.String pwd) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(snsSp);
_data.writeString(id);
_data.writeString(pwd);
mRemote.transact(Stub.TRANSACTION_authLogin, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int authLogout(int appID, int snsSp) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(snsSp);
mRemote.transact(Stub.TRANSACTION_authLogout, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int authKeyResolve(int appID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
mRemote.transact(Stub.TRANSACTION_authKeyResolve, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int authKeyDelete(int appID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
mRemote.transact(Stub.TRANSACTION_authKeyDelete, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int activityForward(int appID, java.lang.String activityID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeString(activityID);
mRemote.transact(Stub.TRANSACTION_activityForward, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int activityRetrieve(int appID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
mRemote.transact(Stub.TRANSACTION_activityRetrieve, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int commentPost(int appID, int snsSp, java.lang.String targetID, java.lang.String targetAuthorID, java.lang.String targetType, java.lang.String targetSubID, java.lang.String content) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(snsSp);
_data.writeString(targetID);
_data.writeString(targetAuthorID);
_data.writeString(targetType);
_data.writeString(targetSubID);
_data.writeString(content);
mRemote.transact(Stub.TRANSACTION_commentPost, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int commentRetrieve(int appID, int snsSp, java.lang.String targetID, java.lang.String targetAuthorID, java.lang.String targetType, java.lang.String targetSubID, boolean bFetchFromServer) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(snsSp);
_data.writeString(targetID);
_data.writeString(targetAuthorID);
_data.writeString(targetType);
_data.writeString(targetSubID);
_data.writeInt(((bFetchFromServer)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_commentRetrieve, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int commentRetrieveNext(int appID, int snsSp, java.lang.String targetID, java.lang.String targetAuthorID, java.lang.String targetType, java.lang.String targetSubID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(snsSp);
_data.writeString(targetID);
_data.writeString(targetAuthorID);
_data.writeString(targetType);
_data.writeString(targetSubID);
mRemote.transact(Stub.TRANSACTION_commentRetrieveNext, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int friendListRetrieve(int appID, int snsSp) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(snsSp);
mRemote.transact(Stub.TRANSACTION_friendListRetrieve, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int messageFolderRetrieve(int appID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
mRemote.transact(Stub.TRANSACTION_messageFolderRetrieve, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int messageGet(int appID, int snsSp, java.lang.String threadID, java.lang.String messageID, java.lang.String messageFolder) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(snsSp);
_data.writeString(threadID);
_data.writeString(messageID);
_data.writeString(messageFolder);
mRemote.transact(Stub.TRANSACTION_messageGet, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int messagePost(int appID, int snsSp, java.lang.String[] receiverIDs, java.lang.String title, java.lang.String content, java.lang.String replyMessageID, java.lang.String replyThreadID, java.lang.String replyFolder) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(snsSp);
_data.writeStringArray(receiverIDs);
_data.writeString(title);
_data.writeString(content);
_data.writeString(replyMessageID);
_data.writeString(replyThreadID);
_data.writeString(replyFolder);
mRemote.transact(Stub.TRANSACTION_messagePost, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int messageThreadRetrieve(int appID, java.lang.String folder, java.lang.String threadID, boolean bFetchFromServer) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeString(folder);
_data.writeString(threadID);
_data.writeInt(((bFetchFromServer)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_messageThreadRetrieve, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int messageThreadRetrieveNext(int appID, java.lang.String folder, java.lang.String threadID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeString(folder);
_data.writeString(threadID);
mRemote.transact(Stub.TRANSACTION_messageThreadRetrieveNext, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int notificationPost(int appID, int[] spTypeList) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeIntArray(spTypeList);
mRemote.transact(Stub.TRANSACTION_notificationPost, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int peopleProfileGet(int appID, int spType) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(spType);
mRemote.transact(Stub.TRANSACTION_peopleProfileGet, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int peopleProfileSet(int appID, int[] spTypeList, java.lang.String status) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeIntArray(spTypeList);
_data.writeString(status);
mRemote.transact(Stub.TRANSACTION_peopleProfileSet, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int photoAlbumGet(int appID, int snsSp, java.lang.String peopleID, boolean bFetchFromServer) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(snsSp);
_data.writeString(peopleID);
_data.writeInt(((bFetchFromServer)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_photoAlbumGet, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int photoAlbumGetNext(int appID, int snsSp, java.lang.String peopleID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(snsSp);
_data.writeString(peopleID);
mRemote.transact(Stub.TRANSACTION_photoAlbumGetNext, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int photoAlbumRetrieve(int appID, int snsSp, java.lang.String albumID, java.lang.String peopleID, boolean bFetchFromServer) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(snsSp);
_data.writeString(albumID);
_data.writeString(peopleID);
_data.writeInt(((bFetchFromServer)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_photoAlbumRetrieve, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int photoAlbumRetrieveNext(int appID, int snsSp, java.lang.String albumID, java.lang.String peopleID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(snsSp);
_data.writeString(albumID);
_data.writeString(peopleID);
mRemote.transact(Stub.TRANSACTION_photoAlbumRetrieveNext, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int photoGet(int appID, int snsSp, java.lang.String photoID, java.lang.String authorID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(snsSp);
_data.writeString(photoID);
_data.writeString(authorID);
mRemote.transact(Stub.TRANSACTION_photoGet, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int photoGetBody(int appID, java.lang.String photoURL) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeString(photoURL);
mRemote.transact(Stub.TRANSACTION_photoGetBody, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int photoUpload(int appID, int snsSp, java.lang.String fileName, java.lang.String content, java.lang.String title, java.lang.String tag, android.os.ParcelFileDescriptor pfd) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(snsSp);
_data.writeString(fileName);
_data.writeString(content);
_data.writeString(title);
_data.writeString(tag);
if ((pfd!=null)) {
_data.writeInt(1);
pfd.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_photoUpload, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int scheduleRetrieve(int appID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
mRemote.transact(Stub.TRANSACTION_scheduleRetrieve, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int serviceProviderDeepLinkGet(int appID, int snsSp, java.lang.String linkType, java.lang.String deeplinkUrl, java.lang.String peopleID, java.lang.String targetID, java.lang.String targetSubID, java.lang.String targetCommentID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(snsSp);
_data.writeString(linkType);
_data.writeString(deeplinkUrl);
_data.writeString(peopleID);
_data.writeString(targetID);
_data.writeString(targetSubID);
_data.writeString(targetCommentID);
mRemote.transact(Stub.TRANSACTION_serviceProviderDeepLinkGet, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public boolean abortPhotoUpload(int appID, int reqID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(reqID);
mRemote.transact(Stub.TRANSACTION_abortPhotoUpload, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public boolean abortPhotoDownload(int appID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
mRemote.transact(Stub.TRANSACTION_abortPhotoDownload, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public boolean abortPhotoDownloadByRequestId(int appID, int reqID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(reqID);
mRemote.transact(Stub.TRANSACTION_abortPhotoDownloadByRequestId, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int syncContactsNow(int appID, int spType) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(spType);
mRemote.transact(Stub.TRANSACTION_syncContactsNow, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int syncCalendarNow(int appID, int spType) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(spType);
mRemote.transact(Stub.TRANSACTION_syncCalendarNow, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public boolean cancelSync(int appID, int syncID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(syncID);
mRemote.transact(Stub.TRANSACTION_cancelSync, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int snsGatewayHostGet(int appID) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
mRemote.transact(Stub.TRANSACTION_snsGatewayHostGet, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int oAuthCredentialGet(int appID, int spType, java.lang.String url, java.lang.String mimeType) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(appID);
_data.writeInt(spType);
_data.writeString(url);
_data.writeString(mimeType);
mRemote.transact(Stub.TRANSACTION_oAuthCredentialGet, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_authLogin = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_authLogout = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_authKeyResolve = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_authKeyDelete = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_activityForward = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_activityRetrieve = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_commentPost = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_commentRetrieve = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_commentRetrieveNext = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_friendListRetrieve = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_messageFolderRetrieve = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_messageGet = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
static final int TRANSACTION_messagePost = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
static final int TRANSACTION_messageThreadRetrieve = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
static final int TRANSACTION_messageThreadRetrieveNext = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
static final int TRANSACTION_notificationPost = (android.os.IBinder.FIRST_CALL_TRANSACTION + 15);
static final int TRANSACTION_peopleProfileGet = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16);
static final int TRANSACTION_peopleProfileSet = (android.os.IBinder.FIRST_CALL_TRANSACTION + 17);
static final int TRANSACTION_photoAlbumGet = (android.os.IBinder.FIRST_CALL_TRANSACTION + 18);
static final int TRANSACTION_photoAlbumGetNext = (android.os.IBinder.FIRST_CALL_TRANSACTION + 19);
static final int TRANSACTION_photoAlbumRetrieve = (android.os.IBinder.FIRST_CALL_TRANSACTION + 20);
static final int TRANSACTION_photoAlbumRetrieveNext = (android.os.IBinder.FIRST_CALL_TRANSACTION + 21);
static final int TRANSACTION_photoGet = (android.os.IBinder.FIRST_CALL_TRANSACTION + 22);
static final int TRANSACTION_photoGetBody = (android.os.IBinder.FIRST_CALL_TRANSACTION + 23);
static final int TRANSACTION_photoUpload = (android.os.IBinder.FIRST_CALL_TRANSACTION + 24);
static final int TRANSACTION_scheduleRetrieve = (android.os.IBinder.FIRST_CALL_TRANSACTION + 25);
static final int TRANSACTION_serviceProviderDeepLinkGet = (android.os.IBinder.FIRST_CALL_TRANSACTION + 26);
static final int TRANSACTION_abortPhotoUpload = (android.os.IBinder.FIRST_CALL_TRANSACTION + 27);
static final int TRANSACTION_abortPhotoDownload = (android.os.IBinder.FIRST_CALL_TRANSACTION + 28);
static final int TRANSACTION_abortPhotoDownloadByRequestId = (android.os.IBinder.FIRST_CALL_TRANSACTION + 29);
static final int TRANSACTION_syncContactsNow = (android.os.IBinder.FIRST_CALL_TRANSACTION + 30);
static final int TRANSACTION_syncCalendarNow = (android.os.IBinder.FIRST_CALL_TRANSACTION + 31);
static final int TRANSACTION_cancelSync = (android.os.IBinder.FIRST_CALL_TRANSACTION + 32);
static final int TRANSACTION_snsGatewayHostGet = (android.os.IBinder.FIRST_CALL_TRANSACTION + 33);
static final int TRANSACTION_oAuthCredentialGet = (android.os.IBinder.FIRST_CALL_TRANSACTION + 34);
}
public int authLogin(int appID, int snsSp, java.lang.String id, java.lang.String pwd) throws android.os.RemoteException;
public int authLogout(int appID, int snsSp) throws android.os.RemoteException;
public int authKeyResolve(int appID) throws android.os.RemoteException;
public int authKeyDelete(int appID) throws android.os.RemoteException;
public int activityForward(int appID, java.lang.String activityID) throws android.os.RemoteException;
public int activityRetrieve(int appID) throws android.os.RemoteException;
public int commentPost(int appID, int snsSp, java.lang.String targetID, java.lang.String targetAuthorID, java.lang.String targetType, java.lang.String targetSubID, java.lang.String content) throws android.os.RemoteException;
public int commentRetrieve(int appID, int snsSp, java.lang.String targetID, java.lang.String targetAuthorID, java.lang.String targetType, java.lang.String targetSubID, boolean bFetchFromServer) throws android.os.RemoteException;
public int commentRetrieveNext(int appID, int snsSp, java.lang.String targetID, java.lang.String targetAuthorID, java.lang.String targetType, java.lang.String targetSubID) throws android.os.RemoteException;
public int friendListRetrieve(int appID, int snsSp) throws android.os.RemoteException;
public int messageFolderRetrieve(int appID) throws android.os.RemoteException;
public int messageGet(int appID, int snsSp, java.lang.String threadID, java.lang.String messageID, java.lang.String messageFolder) throws android.os.RemoteException;
public int messagePost(int appID, int snsSp, java.lang.String[] receiverIDs, java.lang.String title, java.lang.String content, java.lang.String replyMessageID, java.lang.String replyThreadID, java.lang.String replyFolder) throws android.os.RemoteException;
public int messageThreadRetrieve(int appID, java.lang.String folder, java.lang.String threadID, boolean bFetchFromServer) throws android.os.RemoteException;
public int messageThreadRetrieveNext(int appID, java.lang.String folder, java.lang.String threadID) throws android.os.RemoteException;
public int notificationPost(int appID, int[] spTypeList) throws android.os.RemoteException;
public int peopleProfileGet(int appID, int spType) throws android.os.RemoteException;
public int peopleProfileSet(int appID, int[] spTypeList, java.lang.String status) throws android.os.RemoteException;
public int photoAlbumGet(int appID, int snsSp, java.lang.String peopleID, boolean bFetchFromServer) throws android.os.RemoteException;
public int photoAlbumGetNext(int appID, int snsSp, java.lang.String peopleID) throws android.os.RemoteException;
public int photoAlbumRetrieve(int appID, int snsSp, java.lang.String albumID, java.lang.String peopleID, boolean bFetchFromServer) throws android.os.RemoteException;
public int photoAlbumRetrieveNext(int appID, int snsSp, java.lang.String albumID, java.lang.String peopleID) throws android.os.RemoteException;
public int photoGet(int appID, int snsSp, java.lang.String photoID, java.lang.String authorID) throws android.os.RemoteException;
public int photoGetBody(int appID, java.lang.String photoURL) throws android.os.RemoteException;
public int photoUpload(int appID, int snsSp, java.lang.String fileName, java.lang.String content, java.lang.String title, java.lang.String tag, android.os.ParcelFileDescriptor pfd) throws android.os.RemoteException;
public int scheduleRetrieve(int appID) throws android.os.RemoteException;
public int serviceProviderDeepLinkGet(int appID, int snsSp, java.lang.String linkType, java.lang.String deeplinkUrl, java.lang.String peopleID, java.lang.String targetID, java.lang.String targetSubID, java.lang.String targetCommentID) throws android.os.RemoteException;
public boolean abortPhotoUpload(int appID, int reqID) throws android.os.RemoteException;
public boolean abortPhotoDownload(int appID) throws android.os.RemoteException;
public boolean abortPhotoDownloadByRequestId(int appID, int reqID) throws android.os.RemoteException;
public int syncContactsNow(int appID, int spType) throws android.os.RemoteException;
public int syncCalendarNow(int appID, int spType) throws android.os.RemoteException;
public boolean cancelSync(int appID, int syncID) throws android.os.RemoteException;
public int snsGatewayHostGet(int appID) throws android.os.RemoteException;
public int oAuthCredentialGet(int appID, int spType, java.lang.String url, java.lang.String mimeType) throws android.os.RemoteException;
}
