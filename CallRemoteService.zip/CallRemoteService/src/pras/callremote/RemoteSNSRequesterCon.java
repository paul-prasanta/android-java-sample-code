package pras.callremote;

import com.sec.android.app.sns.ISnsRequester;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;

public class RemoteSNSRequesterCon implements ServiceConnection {

	String TAG = getClass().getSimpleName();
	ISnsRequester requester;
	
	public void onServiceConnected(ComponentName cmp, IBinder binder) {
		Log.v(TAG, "onServiceConnected_______");
		requester = ISnsRequester.Stub.asInterface(binder);
		Log.v(TAG, "Requester: "+ requester);
		int res = 999;
		try{
			// it works
			//res = requester.authLogin(100, 100, "id", "pwd");
			//res = requester.activityRetrieve(100);
			//res = requester.commentPost(100, 100, "targetID", "targetAuthorID", "targetType", "content");
			//res = requester.commentPost(100, 100, "TargetID", "Auth", "targetType", "targetSubID", "content");
			//res = requester.commentRetrieve(100, 100, "targetID", "targetAuthorID", "targetType", true);
		}catch(Exception ex){
			Log.e(TAG, "Error in AIDL connect: "+ ex.toString());
			ex.printStackTrace();
		}
		Log.v(TAG, "Able to connect to AIDL methods!!...Res="+ res);
	}

	public void onServiceDisconnected(ComponentName cmp) {
		Log.v(TAG, "onServiceDisconnected_______");
	}

}
