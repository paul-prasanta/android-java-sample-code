package pras.callremote;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

/**
 * @author prasanta
 *
 */
public class CallRemoteService extends Activity implements OnClickListener {
    
	
	TextView text;
	RemoteServiceCon serCon;
	public static String REM_SER_ACTION = "com.my.service.REMOTE_SERVICE";
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        findViewById(R.id.Button_Bind).setOnClickListener(this);
        findViewById(R.id.Button_UnBind).setOnClickListener(this);
        text = (TextView)findViewById(R.id.text);
        
        serCon = new RemoteServiceCon(this);
    }
    
	public void updateText(String msg){
		text.setText(msg);
	}
	
    private void connectRemoteSer(){
    	//Intent intent = new Intent(REM_SER_ACTION);
    	// 4th Jan, 2011: Google Geo Coder Service check
    	//Intent intent = new Intent("com.google.android.location.GeocodeProvider");
    	Intent intent = new Intent("com.google.android.location.NetworkLocationProvider");
    	this.bindService(intent, serCon, Context.BIND_AUTO_CREATE);
    }

	public void onClick(View v) {
		if(v.getId() == R.id.Button_Bind){
			text.setText("Binding Remote Service...");
			//bindService(new Intent("com.sec.android.app.sns.ISnsRequester"), new RemoteSNSRequesterCon(), Context.BIND_AUTO_CREATE);
			connectRemoteSer();
		}
		else if(v.getId() == R.id.Button_UnBind){
			text.setText("Unbind Remote Service...");
			this.unbindService(serCon);
		}
	}
	
}