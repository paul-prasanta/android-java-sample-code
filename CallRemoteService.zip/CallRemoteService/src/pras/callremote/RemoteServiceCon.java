package pras.callremote;

import pras.service.aidl.PrasRemote;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

public class RemoteServiceCon implements ServiceConnection {

	final String TAG = "RemoteServiceCon";
	PrasRemote remoteIntf;
	CallRemoteService client;
	
	public RemoteServiceCon(CallRemoteService client){
		this.client = client;
	}
	
	public void onServiceConnected(ComponentName cmp, IBinder binder) {
		/*
		 * Call back when call is established with the remote service
		 */
		Log.i(TAG, "onServiceConnected: Comp: "+ cmp.flattenToString());
		Log.i(TAG, "Class Name: "+ cmp.getClassName() +" Package: "+ cmp.getPackageName());
		/*remoteIntf = PrasRemote.Stub.asInterface(binder);
		try{
			String remoteMsg = remoteIntf.sayHello("Prasanta");
			Log.v(TAG, "Output "+ remoteMsg);
			client.updateText(remoteMsg);
		}catch(RemoteException ex){
			Log.i(TAG, "Error: "+ ex.toString());
			ex.toString();
		}*/
	}

	public void onServiceDisconnected(ComponentName cmp) {
		/*
		 * Handle unexpected service disconnect
		 */
		Log.i(TAG, "onServiceDisconnected "+ cmp.flattenToString());
		//client.updateText("onServiceDisconnected");
	}

}
