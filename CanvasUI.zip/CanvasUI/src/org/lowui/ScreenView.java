package org.lowui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

/**
 * Display on the whole screen
 * @author prasanta
 *
 */
public class ScreenView extends View {

	String TAG = "ScreenView";
	
	public static final int SECTION_TOP = 0xA1;
	public static final int SECTION_MIDDLE = 0xA2;
	public static final int SECTION_BOTTOM = 0xA3;
	
	Paint text_color = new Paint();
	Paint bg = new Paint();
	Context context;
	
	Region sRegion;
	MyViewEventListener listener;
	
	int transparent = 0x00;
	
	public interface MyViewEventListener{
		public void dragEvent(int section);
	}
	
	public ScreenView(Context context, MyViewEventListener listener) {
		super(context);
		this.context = context;
		this.listener = listener;
		init();
	}

	private void init(){
		//bg 
		bg.setColor(0xFFFFFFFF);
		// text
		text_color.setColor(0xFFFFFFFF);
		text_color.setTextSize(28);
		text_color.setTextSkewX(-0.25f);
		
		/*Thread th = new Thread(){
			public void run(){
				while(true){
					invalidate();
					try{
						Thread.sleep(1000);
					}catch(Exception ex){
						ex.printStackTrace();
					}
				}
			}
		};
		th.start();*/
	}
	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		Log.i(TAG, "onMeasure....");
		Log.i(TAG, "Screen Width: "+ getWidth());
		Log.i(TAG, "Screen Height: "+ getHeight());
		//setMeasuredDimension(getWidth(), getHeight());
		setWidthHeight();
	}

	private void setWidthHeight(){
		/*
		 * Get the screen width and height
		 */
		Display display = ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay(); 
		setMeasuredDimension(display.getWidth(), display.getHeight());
	}

	@Override
	protected void onDraw(Canvas canvas) {
		//super.onDraw(canvas);
		
		Log.i(TAG, "<-onDraw->");
		Display display = ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay(); 
		int width = display.getWidth(); //canvas.getWidth();
		int height = display.getHeight(); //canvas.getWidth();
		
		Log.i(TAG, "Width:"+ width);
		Log.i(TAG, "Height: "+ height);
		
		Rect r = new Rect(0, 0, width, height);
		
		canvas.drawRect(r, bg);
		
		drawTransParentPopup(canvas, 10, 20);
		
		Bitmap bm = createArrow(40, 20);//getImage();
		canvas.save();
		canvas.rotate(-180, 100 + bm.getWidth()/2, 100 + bm.getHeight()/2);
		canvas.drawBitmap(bm, 100, 100, null);
		canvas.restore();
		
		// add fading layer
		
		if(transparent >= 0xFF)
			transparent = 0x00;
		else
			transparent = transparent + 0x05;
		Paint fadePaint = new Paint();
		fadePaint.setARGB(transparent, 0xFF, 0xFF, 0xFF);
		canvas.drawRect(r, fadePaint);
		/*
		//canvas.drawText("Snooze", 10, 20, text_color);
		
		// Draw a  sensitive Circle
		Path sCircle = getCustomFigure(width/2, height/2);
		Paint cp = new Paint();
		cp.setStyle(Paint.Style.FILL);
		cp.setColor(Color.RED);
		canvas.drawPath(sCircle, cp);
		
		// Define Region
		sRegion = new Region();
		// my clip is complete screen
		Region clip = new Region(0, 0, width, height);
		sRegion.setPath(sCircle, clip);
		
		canvas.save();
		
		//canvas.drawText("Stop", 10, height/2, text_color);
		drawRotatedText(canvas, "Stop", 10, height/2);
		
		canvas.restore();*/
	}
	
	private void drawTransParentPopup(Canvas canvas, int x, int y){
		String str = "Number of Pins: "+ 10;
		
		Paint p = new Paint();
		p.setStyle(Paint.Style.FILL);
		p.setColor(0x55000000);
		p.setTextSize((float)20);
		Typeface tf = Typeface.create(Typeface.DEFAULT, Typeface.BOLD);
		p.setTypeface(tf);
		
		int txtWidth = (int)p.measureText(str);
		int txtHeight = (int)p.getTextSize();
		
		Log.i(TAG, "txtWidth: "+ txtWidth);
		Log.i(TAG, "txtHeight: "+ txtHeight);
		
		int padW = 5;
		int padH = 5;
		
		Rect popUp = new Rect(x, y, x + txtWidth + 2*padW, y + txtHeight + 2*padH);
		
		/*
		 * Rotate Canvas
		 */
		canvas.rotate(-15, x + popUp.exactCenterX(), y + popUp.exactCenterY());
		
		// draw transparent Popup
		Paint rectPaint = new Paint();
		rectPaint.setStyle(Paint.Style.FILL);
		rectPaint.setColor(0x0A858585); // semi-transparent Popup
		canvas.drawRect(popUp, rectPaint);
		
		// draw Text over the Transparent Popup- find the bottom
		canvas.drawText(str, (int)(x + padW), (int)(y + txtHeight), p);
		
		// restore the Canvas
		canvas.restore();
	}
	
	private Bitmap createArrow(int width, int height){
		Bitmap mutable = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
		// draw on bitmap
		Canvas c = new Canvas(mutable);
		Path path = new Path();
		Paint paint = new Paint();
		paint.setColor(0xFF0000FF);
		
		int partW = width/4;
		// start position for Arrow
		int x = 3 * partW;
		int y = height/2;
		
		// upper arrow- head
		path.moveTo(x, y);
		path.lineTo(x, 0);
		path.lineTo(width, y);
		path.lineTo(x, height);
		
		// draw arrow-line
		path.moveTo(x, y);
		path.lineTo(x, y - height/4);
		path.lineTo(0, y - height/4);
		path.lineTo(0, y + height/4);
		path.lineTo(x, y + height/4);
		
		c.drawPath(path, paint);
		
		// draw border
		Paint border = new Paint();
		border.setColor(0xFF00FF00);
		border.setStyle(Paint.Style.STROKE);
		
		c.drawRect(0, 0, mutable.getWidth()-1, mutable.getHeight()-1, border);
		
		return mutable;
	}
	
	private void drawRotatedText(Canvas canvas, String text, float x, float y){
		
		// Get the 
		Rect boundR = new Rect();
		text_color.getTextBounds(text, 0, text.length(), boundR);
		
		/*canvas.translate(x, y);
		canvas.drawText(text, 0, 0, text_color);
		canvas.drawRect(boundR, text_color);
		
		canvas.translate(-x, -y);*/
		
		text_color.setColor(Color.RED);
		/*
		 * Steps for Slat view-
		 * 1. Rotate Canvas with desired angle
		 * 2. Draw your content (text, image etc.)
		 * 3. Restore back Canvas, so that other drawing doesn't get
		 * effected
		 */
		canvas.rotate(-45, x + boundR.exactCenterX(),y + boundR.exactCenterY());
		text_color.setStyle(Paint.Style.FILL);
		canvas.drawText(text, x, y, text_color);
		canvas.restore();
	}
	
	private Path getCustomFigure(int x, int y){
		Path p = new Path();
		p.addCircle(x, y, 40, Path.Direction.CW);
		return p;
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		Log.i(TAG, "onTouchEvent");
		int x = (int)event.getRawX();
		int y = (int)event.getRawY();
		
		Log.i(TAG, "Clicked on ["+x +", "+ y+"]");
		if(sRegion == null)
			return true;
		
		Log.i(TAG, "You hit on Sensitive Region ? "+ sRegion.contains(x, y));
		
		if(listener != null)
			listener.dragEvent(SECTION_TOP);
		
		return super.onTouchEvent(event);
	}
}
