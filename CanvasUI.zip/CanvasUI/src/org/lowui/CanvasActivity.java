package org.lowui;

import org.lowui.ScreenView.MyViewEventListener;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class CanvasActivity extends Activity implements MyViewEventListener {
	
	String TAG = "CanvasActivity";
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        ScreenView sView = new ScreenView(this.getApplicationContext(), this);
        setContentView(sView);
    }

    
	public void dragEvent(int section) {
		Log.i(TAG, "Section Touched: "+ section);
	}
}